
// Load Tesseract.js and Math.js from CDN
const tesseractScript = document.createElement('script');
tesseractScript.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@2.1.1/dist/tesseract.min.js';
document.head.appendChild(tesseractScript);

const mathScript = document.createElement('script');
mathScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/mathjs/12.4.0/math.min.js';
document.head.appendChild(mathScript);

function solveMathProblem(expression) {
    try {
        const simplified = math.simplify(expression).toString();
        const evaluated = math.evaluate(expression);
        return `Simplified: ${simplified} \nFinal Answer: ${evaluated}`;
    } catch (error) {
        return "Error solving the problem. Please enter a valid math expression.";
    }
}

document.getElementById("solveBtn").addEventListener("click", () => {
    const input = document.getElementById("mathInput").value;
    const result = solveMathProblem(input);
    document.getElementById("result").innerText = result;
});

document.getElementById("toggleLang").addEventListener("click", () => {
    const title = document.getElementById("title");
    const subtitle = document.getElementById("subtitle");
    if (title.innerText === "Solve Math Problems") {
        title.innerText = "ریاضی کے مسائل حل کریں";
        subtitle.innerText = "اردو اور انگریزی میں پیچیدہ مساوات حل کریں";
    } else {
        title.innerText = "Solve Math Problems";
        subtitle.innerText = "Solve complex equations in English and Urdu";
    }
});

// Camera / OCR support (English + optional Urdu)
document.getElementById("cameraBtn").addEventListener("click", () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        Tesseract.recognize(
            file,
            'eng+urd',  // Urdu support enabled here
            { logger: m => console.log(m) }
        ).then(({ data: { text } }) => {
            document.getElementById("mathInput").value = text.trim();
        });
    };
    input.click();
});
