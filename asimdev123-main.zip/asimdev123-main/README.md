# asimdev123
Solved by Asim is a powerful, student-friendly web app that solves complex math problems in both English and Urdu. It features a 3D animated interface, camera-based question input using OCR, and step-by-step solutions powered by smart math logic. Whether you're studying algebra, equations, or word problems, this tool helps you learn and solve
